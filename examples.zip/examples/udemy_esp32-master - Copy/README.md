# udemy_esp32
Udemy IoT Application Development with the ESP32 Using the ESP-IDF Course Repository

https://www.udemy.com/course/iot-application-development-with-the-esp32-using-the-esp-idf/
